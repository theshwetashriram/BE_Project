/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travelrecommendation;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.mahout.cf.taste.common.Refreshable;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.FastByIDMap;
import org.apache.mahout.cf.taste.impl.common.FastIDSet;
import org.apache.mahout.cf.taste.impl.model.GenericBooleanPrefDataModel;
import org.apache.mahout.cf.taste.impl.recommender.GenericBooleanPrefItemBasedRecommender;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.recommender.ItemBasedRecommender;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;

/**
 *
 * @author Admin
 */
public class TravelRecommendation
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception
    {
        // TODO code application logic here
        FastByIDMap<FastIDSet> userData = new FastByIDMap<>();

        List<String> list = Files.readAllLines(new File("trainingdata.csv").toPath());
        list.remove(0);

//        userData.put(1, new FastIDSet(new long[]
//        {
//            1, 2, 3
//        }));
//        userData.put(2, new FastIDSet(new long[]
//        {
//            1, 2
//        }));
        for (String line : list)
        {
            try
            {
                String[] tokens = line.split(",");
                int userid = Integer.parseInt(tokens[0].trim());
                int cityid = Integer.parseInt(tokens[1].trim());

                FastIDSet set = userData.get(userid);
                if (set == null)
                {
                    set = new FastIDSet();
                    userData.put(userid, set);
                }
                set.add(cityid);
            } catch (Exception exception)
            {
            }
        }

        DataModel dataModel = new GenericBooleanPrefDataModel(userData);
        ItemBasedRecommender r = new GenericBooleanPrefItemBasedRecommender(dataModel, new ItemSimilarity()
        {
            @Override
            public double itemSimilarity(long l, long l1) throws TasteException
            {
                if (l == l1)
                {
                    return 1;
                }
                return 0;
            }

            @Override
            public double[] itemSimilarities(long l, long[] longs) throws TasteException
            {
                double sim[] = new double[longs.length];
                for (int i = 0; i < sim.length; i++)
                {
                    sim[i] = itemSimilarity(l, longs[i]);
                }
                return sim;
            }

            @Override
            public long[] allSimilarItemIDs(long l) throws TasteException
            {
                return new long[0];
            }

            @Override
            public void refresh(Collection<Refreshable> clctn)
            {
            }
        });

        List<RecommendedItem> result = r.recommendedBecause(1, 1, 5);
        for (RecommendedItem item : result)
        {
            System.out.println(item.getItemID() + ":" + item.getValue());
        }

        ServerSocket ss = new ServerSocket(2000);
        while(true)
        {
            System.out.println("Waiting for client");
            Socket s = ss.accept();
            System.out.println("Connected Accepted : "+s);
            BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
            String line=br.readLine();
            String []tokens=line.split(",");
            long userid=Long.parseLong(tokens[0].trim());
            
            List<List<RecommendedItem>> lists=new ArrayList<>();
            for(int i=1;i<tokens.length;i++)
            {
                long cityid=Long.parseLong(tokens[i].trim());
                List<RecommendedItem> rlist=r.recommendedBecause(userid, cityid, 10);
                lists.add(rlist);
            }
            
            Set<Long> recoms=intersect(lists);
            StringBuilder sb=new StringBuilder();
            for(Long l:recoms) sb.append(l).append(",");
            if(sb.length()>0) sb.deleteCharAt(sb.length()-1);
            
            PrintWriter pw=new PrintWriter(s.getOutputStream());
            pw.println(sb);
            pw.close();
            br.close();
            s.close();
        }
    }

    public static Set<Long> intersect(List<List<RecommendedItem>> lists)
    {
        Set<Long> set = new HashSet<>();
        for (RecommendedItem i : lists.get(0))
        {
            set.add(i.getItemID());
        }

        for (int i = 1; i < lists.size(); i++)
        {
            List<RecommendedItem> list = lists.get(i);

            Set<Long> set2 = new HashSet<>();
            for (RecommendedItem j : list)
            {
                set2.add(j.getItemID());
            }

            set.retainAll(set2);
        }

        return set;
    }
}
